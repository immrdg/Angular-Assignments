import {Component, EventEmitter, Input, Output} from '@angular/core';
import {faTrash} from "@fortawesome/free-solid-svg-icons";
import {FaIconComponent} from "@fortawesome/angular-fontawesome";
import {NgForOf, UpperCasePipe} from "@angular/common";
import {Song} from "../song-list/song-list.component";

@Component({
  selector: 'app-fav-songs-list',
  standalone: true,
  imports: [
    FaIconComponent,
    NgForOf,
    UpperCasePipe
  ],
  templateUrl: './fav-songs-list.component.html',
  styleUrl: './fav-songs-list.component.css'
})
export class FavSongsListComponent {

  @Input()
  songs: Song[]=[];
  @Output() deleteFromFavoritesEvent = new EventEmitter<Song>();

  protected readonly faTrash = faTrash;

  deleteFromFavorites(song: Song): void {
    const index = this.songs.findIndex(favSong => favSong.title === song.title);
    if (index !== -1) {
      this.songs.splice(index, 1);
      console.log("emitted")
      this.deleteFromFavoritesEvent.emit(song);
    }
  }
}
