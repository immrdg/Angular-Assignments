import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FavSongsListComponent } from './fav-songs-list.component';

describe('FavSongsListComponent', () => {
  let component: FavSongsListComponent;
  let fixture: ComponentFixture<FavSongsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FavSongsListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FavSongsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
