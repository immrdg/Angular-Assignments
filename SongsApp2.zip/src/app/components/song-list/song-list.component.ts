import {Component, OnInit} from '@angular/core';
import {NgForOf, NgIf, UpperCasePipe} from "@angular/common";
import {FormsModule} from "@angular/forms";
import {FavSongsListComponent} from "../fav-songs-list/fav-songs-list.component";
import {FaIconComponent} from "@fortawesome/angular-fontawesome";
import {faHeart as farHeart} from "@fortawesome/free-regular-svg-icons";
import {faHeart as fasHeart, faTrash} from "@fortawesome/free-solid-svg-icons";

export interface Song {
  title: string;
  isFavorited: boolean;
}

@Component({
  selector: 'app-song-list',
  standalone: true,
  imports: [
    NgForOf,
    FormsModule,
    NgIf,
    UpperCasePipe,
    FavSongsListComponent,
    FaIconComponent
  ],
  templateUrl: './song-list.component.html',
  styleUrl: './song-list.component.css'
})
export class SongListComponent {


  songs: Song[] = [
    { title: 'The Night We Met', isFavorited: false },
    { title: 'Dandelions', isFavorited: false },
    { title: 'Perfect', isFavorited: false },
    { title: 'Lovers', isFavorited: false }
  ];

  favSongs:Song[]= []
  showSongCount = false;
  newSong: string = '';
  fasHeart = fasHeart;
  farHeart = farHeart;


  private titleCase(data: string): string {
    return data.replace(/\w\S*/g, function (word) {
      return word.charAt(0).toUpperCase() + word.substring(1).toLowerCase();
    });
  }

  addSong(): void {
    if (this.newSong.trim() !== '') {
      this.songs.push({ title: this.titleCase(this.newSong), isFavorited: false });
      console.log(this.songs);
      this.newSong = '';
    }
  }

  toggleSongCount(): void {
    this.showSongCount = !this.showSongCount;
  }

  toggleHeart(song: Song): void {
    song.isFavorited = !song.isFavorited;
    if (song.isFavorited) {
      this.favSongs.push(song);
    } else {
      const index = this.favSongs.findIndex(favSong => favSong.title === song.title);
      if (index !== -1) {
        this.favSongs.splice(index, 1);
      }
    }
  }

  protected readonly faTrash = faTrash;

  deleteSong(song: Song) {
    this.songs = this.songs.filter(existingSong => existingSong.title !== song.title);
    this.favSongs = this.favSongs.filter(favSong => favSong.title !== song.title);
  }

  onSongDeletedFromFavorites(song: Song) {
    if (this.favSongs.some(favSong => favSong.title === song.title)) {
      this.favSongs = this.favSongs.filter(favSong => favSong.title !== song.title);
    }

    const index = this.songs.findIndex(existingSong => existingSong.title === song.title);
    if (index !== -1) {
      this.songs[index].isFavorited = false;
    }
  }
}
