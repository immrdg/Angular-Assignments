import { ApplicationConfig } from '@angular/core';
import {HttpClientModule, provideHttpClient} from "@angular/common/http";
import {MdbModalModule, MdbModalService} from "mdb-angular-ui-kit/modal";
import {provideRouter} from "@angular/router";
import {AppComponent} from "./app.component";
import {SongListComponent} from "./components/song-list/song-list.component";
import {ViewSongDetailsComponent} from "./components/view-song-details/view-song-details.component";
import {AboutComponent} from "./components/about/about.component";

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(),
    MdbModalService,

    provideRouter([
      {
        path: "",
        component: AboutComponent,
      },
      {
        path: "Song/:name",
        component: ViewSongDetailsComponent,
      },
      {
        path: "Songs",
        component:SongListComponent
      }
    ]),
  ],
};
