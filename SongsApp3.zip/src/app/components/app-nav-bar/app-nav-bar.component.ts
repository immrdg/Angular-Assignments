import {Component, OnInit} from '@angular/core';
import {CommonModule, NgOptimizedImage} from '@angular/common';
import {ActivatedRoute, NavigationEnd, Router, RouterLink} from "@angular/router";
import {filter, map} from "rxjs";

@Component({
  selector: 'app-nav-bar',
  standalone: true,
  imports: [CommonModule, RouterLink, NgOptimizedImage],
  templateUrl: './app-nav-bar.component.html',
  styleUrls: ['./app-nav-bar.component.css']
})
export class AppNavBarComponent implements OnInit {
  showSongsButton: boolean = false;
  showAboutButton: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd),
      map(() => this.route),
      map(route => {
        while (route.firstChild) route = route.firstChild;
        return route;
      }),
      map(route => route.snapshot.url)
    ).subscribe(urlSegments => {
      const currentUrl = urlSegments.join('/');
      this.showSongsButton = currentUrl !== 'Songs';
      this.showAboutButton = currentUrl !== '';
    });
  }
}
