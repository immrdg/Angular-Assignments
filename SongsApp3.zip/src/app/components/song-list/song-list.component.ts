import {Component, OnInit, TemplateRef} from '@angular/core';
import { CommonModule } from '@angular/common';
import {Song} from "../../models/song";
import {SongService} from "../../services/song.service";
import {FormsModule} from "@angular/forms";
import {MdbModalService} from "mdb-angular-ui-kit/modal";
import {EditSongComponent} from "../modals/edit-song/edit-song.component";
import {DeleteSongComponent} from "../modals/delete-song/delete-song.component";
import {ViewSongDetailsConfirmComponent} from "../modals/view-song-details-confirm/view-song-details-confirm.component";
import {Router} from "@angular/router";
import {log10} from "chart.js/helpers";

@Component({
  selector: 'app-song-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './song-list.component.html',
  styleUrls: ['./song-list.component.css']
})
export class SongListComponent implements OnInit{

  songs: Song[] = [];
  newSongName:string = '';
  newSongAlbum:string = '';
  selectedSong: Song | null = null;



  constructor(private songService: SongService, protected modalService: MdbModalService,private router: Router) {

  }

  ngOnInit(): void {
    this.loadSongs();
  }

  private loadSongs() {
      this.songService.getAllSongs().subscribe((songs)=>this.songs=songs);
  }
  addSong() {

    const newSong: any = { name: this.newSongName, album: this.newSongAlbum };

    this.songService.addSong(newSong).subscribe(() => {
      this.loadSongs();
      this.newSongName = '';
      this.newSongAlbum='';
    });
  }

  openEditModal( song: Song): void {
    this.selectedSong = { ...song };
    let editSongComponentMdbModalRef = this.modalService.open( EditSongComponent,{
      data: { song:this.selectedSong},modalClass:'modal-dialog-centered',ignoreBackdropClick:true
    });
    editSongComponentMdbModalRef.onClose.subscribe((message)=>{
      if (message=='success')
        this.loadSongs();
    });
  }


  openDeleteModal( song: Song): void {
    this.selectedSong = { ...song };
    let  deleteSongModalRef = this.modalService.open( DeleteSongComponent,{
      data: { song:this.selectedSong},modalClass:'modal-dialog-centered modal-md',ignoreBackdropClick:true,backdrop:true
    });
    deleteSongModalRef.onClose.subscribe(
      (message)=>{
        if (message=='success')
          this.loadSongs()
      }
    )
  }


  viewMore(song: Song): void {
    this.selectedSong = { ...song };
    let viewMoreModalRef  = this.modalService.open(ViewSongDetailsConfirmComponent,
      {
        data: { song:this.selectedSong},
        modalClass:'modal-dialog-top',
        ignoreBackdropClick:true
      }
      );
    viewMoreModalRef.onClose.subscribe(
      (message)=>{
        if(message=='success'){
          this.router.navigate(['/Song', this.selectedSong?.name]).then((r) => {
            console.log(r)});
        }
      }
    )
  }
}
