import {Component, OnInit} from '@angular/core';
import {CommonModule, NgOptimizedImage} from '@angular/common';
import {ActivatedRoute} from "@angular/router";
import {Song} from "../../models/song";
import {SongService} from "../../services/song.service";
import {Observable} from "rxjs";

@Component({
  selector: 'app-view-song-details',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage],
  templateUrl: './view-song-details.component.html',
  styleUrls: ['./view-song-details.component.css']
})
export class ViewSongDetailsComponent implements OnInit {

  songName: string='';
  songs:Song[]=[];

  constructor(private route: ActivatedRoute,private songsService:SongService) {

  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const songName = params['name'];
      console.log('Song Name:', songName);
      this.songName = songName;
      // Now you can use the songName in your component logic
      this.songsService.getSongByName(songName).subscribe(
        (song) => {
          console.log(song)
          this.songs.push(...song);
        }
      );
    });
  }

}
