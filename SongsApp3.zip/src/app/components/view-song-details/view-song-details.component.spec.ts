import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSongDetailsComponent } from './view-song-details.component';

describe('ViewSongDetailsComponent', () => {
  let component: ViewSongDetailsComponent;
  let fixture: ComponentFixture<ViewSongDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ViewSongDetailsComponent]
    });
    fixture = TestBed.createComponent(ViewSongDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
