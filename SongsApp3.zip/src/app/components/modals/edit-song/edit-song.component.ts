import {Component, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import {MdbModalRef} from "mdb-angular-ui-kit/modal";
import {Song} from "../../../models/song";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {SongService} from "../../../services/song.service";

@Component({
  selector: 'app-edit-song',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './edit-song.component.html',
  styleUrls: ['./edit-song.component.css']
})
export class EditSongComponent implements OnInit {
  song: Song = {id:1,name:"somename",album:"somealbum"}
  songInitial : Song |undefined;

  constructor(public modalRef: MdbModalRef<EditSongComponent>,private songService:SongService) {

  }

  addSong() {
    console.log(this.song);
    console.log(this.songInitial)
    if(this.songInitial?.album==this.song.album && this.songInitial.name==this.song.name){
      console.log("Lol")
      this.modalRef.close();
      return;
    }
    this.songService.editSong(this.song).subscribe((data)=>{
      console.log(data)});
    console.log("Success")
    this.modalRef.close("success");

  }

  ngOnInit(): void {
    this.songInitial= {...this.song};
    console.log(this.songInitial)
  }
}
