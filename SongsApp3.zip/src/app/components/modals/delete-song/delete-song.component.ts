import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MdbModalRef} from "mdb-angular-ui-kit/modal";
import {SongService} from "../../../services/song.service";
import {Song} from "../../../models/song";

@Component({
  selector: 'app-delete-song',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delete-song.component.html',
  styleUrls: ['./delete-song.component.css']
})
export class DeleteSongComponent {

  song:Song = {id: 0, name:'',album:''}

  constructor(public modalRef: MdbModalRef<DeleteSongComponent>,private songService:SongService) {

  }

  deleteSong() {
    this.songService.deleteSong(this.song.id).subscribe();
    this.modalRef.close('success');
  }
}
