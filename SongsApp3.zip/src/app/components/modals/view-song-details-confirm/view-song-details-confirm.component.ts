import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MdbModalRef} from "mdb-angular-ui-kit/modal";
import {Song} from "../../../models/song";

@Component({
  selector: 'app-view-song-details-confirm',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-song-details-confirm.component.html',
  styleUrls: ['./view-song-details-confirm.component.css']
})
export class ViewSongDetailsConfirmComponent {
  song!:Song;
  protected modalRef: MdbModalRef<ViewSongDetailsConfirmComponent>;


  constructor(modalRef: MdbModalRef<ViewSongDetailsConfirmComponent>) {
    this.modalRef = modalRef;
  }

  viewSong() {
    this.modalRef.close('success');
  }
}
