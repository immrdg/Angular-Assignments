import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSongDetailsConfirmComponent } from './view-song-details-confirm.component';

describe('ViewSongDetailsConfirmComponent', () => {
  let component: ViewSongDetailsConfirmComponent;
  let fixture: ComponentFixture<ViewSongDetailsConfirmComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ViewSongDetailsConfirmComponent]
    });
    fixture = TestBed.createComponent(ViewSongDetailsConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
