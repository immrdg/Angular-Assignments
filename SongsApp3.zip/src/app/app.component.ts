import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SongListComponent} from "./components/song-list/song-list.component";
import {RouterOutlet} from "@angular/router";
import {AppNavBarComponent} from "./components/app-nav-bar/app-nav-bar.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, SongListComponent, RouterOutlet, AppNavBarComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SongsApp3';
}
