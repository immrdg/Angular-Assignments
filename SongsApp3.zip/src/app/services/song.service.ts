import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Song} from "../models/song";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class SongService {

  private serverUrl:string="http://localhost:3000/songs"

  constructor(private http:HttpClient) { }

  public getAllSongs(): Observable<Song[]>{
    return this.http.get<Song[]>(this.serverUrl);
  }

  public getSongByName(name:string): Observable<Song[]>{
    const url = `${this.serverUrl}?name=${name}`;
    return this.http.get<Song[]>(url);

  }
  addSong(song: Song): Observable<Song> {
    return this.http.post<Song>(this.serverUrl, song);
  }

  editSong(song: Song): Observable<Song> {
    console.log("From Server;",song)
    const url = `${this.serverUrl}/${song.id}`;
    return this.http.put<Song>(url, song);
  }

  deleteSong(id: number): Observable<void> {
    const url = `${this.serverUrl}/${id}`;
    return this.http.delete<void>(url);
  }

}
