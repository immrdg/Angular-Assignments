export interface Song {
  id: number;
  name: string;
  album: string;
}
